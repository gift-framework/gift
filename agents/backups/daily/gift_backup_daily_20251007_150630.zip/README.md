# GIFT Maintenance Agents

This directory contains the automated maintenance system for the GIFT framework. The agents ensure document integrity, version control, backup management, and validation of the modular framework structure.

## Agent Architecture

### Core Agents

#### 1. Canonical Documents Agent (`canonical_documents_agent.py`)
- **Purpose**: Enforces PDF documents as canonical references
- **Functions**:
  - Scans and catalogs all PDF documents in `github/docs/`
  - Validates modifications against canonical documents
  - Ensures improvements/deepenings only (no regressions)
  - Maintains document integrity checks

#### 2. Versioning Agent (`versioning_agent.py`)
- **Purpose**: Tracks all modifications with version control
- **Functions**:
  - Records all changes with timestamps and authors
  - Categorizes changes (improvement, deepening, correction, regression)
  - Maintains change history and approval workflow
  - Flags regressions for review

#### 3. Backup Agent (`backup_agent.py`)
- **Purpose**: Automated backup and archival system
- **Functions**:
  - Daily/weekly/monthly automated backups
  - Special canonical document backups
  - Backup integrity verification
  - Automatic cleanup of old backups

#### 4. Validation Agent (`validation_agent.py`)
- **Purpose**: Comprehensive framework validation
- **Functions**:
  - Directory structure validation
  - Mathematical consistency checking
  - Theoretical coherence verification
  - Cross-reference validation
  - Notation consistency checking

#### 5. Main Maintenance Agent (`gift_maintenance_agent.py`)
- **Purpose**: Orchestrates all maintenance activities
- **Functions**:
  - Coordinates daily/weekly maintenance routines
  - Manages automated scheduling
  - Generates comprehensive reports
  - Handles modification validation workflow

## Installation and Setup

### 1. Initial Setup
```bash
cd agents
python setup_agents.py --install-deps
```

### 2. Manual Setup
```bash
# Install dependencies
pip install -r requirements.txt

# Initialize databases and directories
python setup_agents.py
```

## Usage

### Running Maintenance Tasks

#### Daily Maintenance
```bash
python gift_maintenance_agent.py --task daily
```

#### Weekly Maintenance
```bash
python gift_maintenance_agent.py --task weekly
```

#### Individual Agent Tasks
```bash
# Scan canonical documents
python gift_maintenance_agent.py --task canonical

# Run validation
python gift_maintenance_agent.py --task validation

# Create backup
python gift_maintenance_agent.py --task backup
```

### Automated Maintenance

#### Setup Automated Schedule
```bash
python gift_maintenance_agent.py --setup
```

#### Run as Daemon
```bash
python gift_maintenance_agent.py --daemon
```

### Individual Agent Usage

#### Canonical Documents Agent
```bash
python canonical_documents_agent.py
```

#### Versioning Agent
```bash
python versioning_agent.py
```

#### Backup Agent
```bash
python backup_agent.py
```

#### Validation Agent
```bash
python validation_agent.py
```

## Configuration

### Maintenance Configuration (`maintenance_config.json`)
```json
{
  "maintenance_schedule": {
    "canonical_scan": "daily@06:00",
    "validation": "daily@07:00",
    "backup": "daily@02:00",
    "cleanup": "weekly@sunday@04:00"
  },
  "validation_settings": {
    "strict_mode": true,
    "auto_fix": false,
    "require_approval": true
  },
  "backup_settings": {
    "auto_backup": true,
    "include_legacy": false,
    "retention_days": 90
  }
}
```

### Backup Configuration (`backup_config.json`)
```json
{
  "retention_days": {
    "daily": 30,
    "weekly": 90,
    "monthly": 365
  },
  "include_patterns": [
    "github/**",
    "new_work/**",
    "wip_research/**",
    "agents/**",
    "README.md"
  ],
  "exclude_patterns": [
    "legacy/**",
    "backups/**",
    "**/__pycache__/**"
  ]
}
```

## Key Principles

### Canonical Document Enforcement
- **PDF documents in `github/docs/` are canonical references**
- All modifications must be improvements or deepenings
- No regressions from canonical formulations allowed
- Mathematical and theoretical consistency maintained

### Version Control
- Every modification tracked with detailed metadata
- Change categorization (improvement, deepening, correction, regression)
- Approval workflow for significant changes
- Historical tracking and rollback capability

### Backup Strategy
- **Daily backups**: Current work (excluding legacy)
- **Weekly backups**: Complete project (including legacy)
- **Canonical backups**: Special backup of reference documents
- **Automatic cleanup**: Configurable retention periods

### Validation Framework
- **Structure validation**: Modular directory organization
- **Mathematical consistency**: Formula and notation checking
- **Theoretical coherence**: Physics consistency verification
- **Cross-reference integrity**: Link and citation validation

## File Structure

```
agents/
├── README.md                           # This file
├── requirements.txt                    # Python dependencies
├── setup_agents.py                     # Setup script
├── gift_maintenance_agent.py           # Main orchestrating agent
├── canonical_documents_agent.py        # Canonical documents management
├── versioning_agent.py                 # Version control and tracking
├── backup_agent.py                     # Backup and archival system
├── validation_agent.py                 # Framework validation
├── logs/                               # Agent log files
├── reports/                            # Generated reports
├── backups/                            # Backup storage
│   ├── daily/                          # Daily backups
│   ├── weekly/                         # Weekly backups
│   ├── monthly/                        # Monthly backups
│   └── canonical/                      # Canonical document backups
├── canonical_database.json             # Canonical documents database
├── version_database.json               # Version tracking database
├── validation_database.json            # Validation results database
├── backup_config.json                  # Backup configuration
├── maintenance_config.json             # Maintenance configuration
└── setup_complete.json                 # Setup completion marker
```

## Monitoring and Reports

### Daily Reports
- Canonical documents status
- Validation issues summary
- Backup status
- System health

### Weekly Reports
- Version history summary
- Comprehensive backup status
- Trend analysis
- Performance metrics

### Log Files
- All agent activities logged
- Error tracking and debugging
- Performance monitoring
- Audit trail

## Troubleshooting

### Common Issues

1. **Missing Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Permission Errors**
   - Ensure write permissions for `agents/` directory
   - Check backup directory permissions

3. **Canonical Documents Not Found**
   - Verify `github/docs/` directory exists
   - Check PDF files are present

4. **Validation Failures**
   - Check directory structure in `new_work/`
   - Verify document formatting

### Support

For issues or questions:
1. Check log files in `agents/logs/`
2. Review generated reports in `agents/reports/`
3. Verify configuration files
4. Run individual agents for debugging

## Development

### Adding New Agents
1. Create agent class following existing patterns
2. Add to main maintenance agent orchestration
3. Update configuration and setup scripts
4. Add tests and documentation

### Extending Functionality
- Mathematical validation: Integrate SymPy or similar
- NLP analysis: Use spaCy for content analysis
- Machine learning: Add predictive validation
- Web integration: API endpoints for remote management
